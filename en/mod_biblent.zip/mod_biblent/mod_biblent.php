<?php 
/**
 * @ mod_bibliant.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined('_JEXEC') or die('Restricted access'); 
JHtml::_('behavior.keepalive');

$db = JFactory::getDBO();
$query = "SELECT livro,nr,versiculo FROM #__nt ORDER BY rand( )";
$db->setQuery( $query, 0, 1 );
//$reg_rand = $db->loadObjectList();
$reg_rand = $db->loadRow();

if(isset($reg_rand[0])){
	print "<div class=\"login-greeting\"><b>Book</b>: <i>".$reg_rand[0].', Verse: '.$reg_rand[1].'><br>'.$reg_rand[2].'</i></div>';
}	
?> 
