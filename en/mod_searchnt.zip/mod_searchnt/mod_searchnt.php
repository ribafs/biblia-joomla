<?php 
/**
 * @ mod_buscant.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined('_JEXEC') or die('Restricted access'); 
JHtml::_('behavior.keepalive');

$livron='';
$nrn='';
?> 

<form method="post" action="" id="login-form">
<div class="form-group">
<table class="table table-sm">
<div class="form-group">
<tr><td><select name="livron" id="modlgn-username" class="inputbox">
<option value="Matthew 1">Matthew 1
<option value="Matthew 2">Matthew 2
<option value="Matthew 3">Matthew 3
<option value="Matthew 4">Matthew 4
<option value="Matthew 5">Matthew 5
<option value="Matthew 6">Matthew 6
<option value="Matthew 7">Matthew 7
<option value="Matthew 8">Matthew 8
<option value="Matthew 9">Matthew 9
<option value="Matthew 10">Matthew 10
<option value="Matthew 11">Matthew 11
<option value="Matthew 12">Matthew 12
<option value="Matthew 13">Matthew 13
<option value="Matthew 14">Matthew 14
<option value="Matthew 15">Matthew 15
<option value="Matthew 16">Matthew 16
<option value="Matthew 17">Matthew 17
<option value="Matthew 18">Matthew 18
<option value="Matthew 19">Matthew 19
<option value="Matthew 20">Matthew 20
<option value="Matthew 21">Matthew 21
<option value="Matthew 22">Matthew 22
<option value="Matthew 23">Matthew 23
<option value="Matthew 24">Matthew 24
<option value="Matthew 25">Matthew 25
<option value="Matthew 26">Matthew 26
<option value="Matthew 27">Matthew 27
<option value="Matthew 28">Matthew 28
<option value="Mark 1">Mark 1
<option value="Mark 2">Mark 2
<option value="Mark 3">Mark 3
<option value="Mark 4">Mark 4
<option value="Mark 5">Mark 5
<option value="Mark 6">Mark 6
<option value="Mark 7">Mark 7
<option value="Mark 8">Mark 8
<option value="Mark 9">Mark 9
<option value="Mark 10">Mark 10
<option value="Mark 11">Mark 11
<option value="Mark 12">Mark 12
<option value="Mark 13">Mark 13
<option value="Mark 14">Mark 14
<option value="Mark 15">Mark 15
<option value="Mark 16">Mark 16
<option value="Luke 1">Luke 1
<option value="Luke 2">Luke 2
<option value="Luke 3">Luke 3
<option value="Luke 4">Luke 4
<option value="Luke 5">Luke 5
<option value="Luke 6">Luke 6
<option value="Luke 7">Luke 7
<option value="Luke 8">Luke 8
<option value="Luke 9">Luke 9
<option value="Luke 10">Luke 10
<option value="Luke 11">Luke 11
<option value="Luke 12">Luke 12
<option value="Luke 13">Luke 13
<option value="Luke 14">Luke 14
<option value="Luke 15">Luke 15
<option value="Luke 16">Luke 16
<option value="Luke 17">Luke 17
<option value="Luke 18">Luke 18
<option value="Luke 19">Luke 19
<option value="Luke 20">Luke 20
<option value="Luke 21">Luke 21
<option value="Luke 22">Luke 22
<option value="Luke 23">Luke 23
<option value="Luke 24">Luke 24
<option value="John 1">John 1
<option value="John 2">John 2
<option value="John 3">John 3
<option value="John 4">John 4
<option value="John 5">John 5
<option value="John 6">John 6
<option value="John 7">John 7
<option value="John 8">John 8
<option value="John 9">John 9
<option value="John 10">John 10
<option value="John 11">John 11
<option value="John 12">John 12
<option value="John 13">John 13
<option value="John 14">John 14
<option value="John 15">John 15
<option value="John 16">John 16
<option value="John 17">John 17
<option value="John 18">John 18
<option value="John 19">John 19
<option value="John 20">John 20
<option value="John 21">John 21
<option value="Acts 1">Acts 1
<option value="Acts 2">Acts 2
<option value="Acts 3">Acts 3
<option value="Acts 4">Acts 4
<option value="Acts 5">Acts 5
<option value="Acts 6">Acts 6
<option value="Acts 7">Acts 7
<option value="Acts 8">Acts 8
<option value="Acts 9">Acts 9
<option value="Acts 10">Acts 10
<option value="Acts 11">Acts 11
<option value="Acts 12">Acts 12
<option value="Acts 13">Acts 13
<option value="Acts 14">Acts 14
<option value="Acts 15">Acts 15
<option value="Acts 16">Acts 16
<option value="Acts 17">Acts 17
<option value="Acts 18">Acts 18
<option value="Acts 19">Acts 19
<option value="Acts 20">Acts 20
<option value="Acts 21">Acts 21
<option value="Acts 22">Acts 22
<option value="Acts 23">Acts 23
<option value="Acts 24">Acts 24
<option value="Acts 25">Acts 25
<option value="Acts 26">Acts 26
<option value="Acts 27">Acts 27
<option value="Acts 28">Acts 28
<option value="Romans 1">Romans 1
<option value="Romans 2">Romans 2
<option value="Romans 3">Romans 3
<option value="Romans 4">Romans 4
<option value="Romans 5">Romans 5
<option value="Romans 6">Romans 6
<option value="Romans 7">Romans 7
<option value="Romans 8">Romans 8
<option value="Romans 9">Romans 9
<option value="Romans 10">Romans 10
<option value="Romans 11">Romans 11
<option value="Romans 12">Romans 12
<option value="Romans 13">Romans 13
<option value="Romans 14">Romans 14
<option value="Romans 15">Romans 15
<option value="Romans 16">Romans 16
<option value="I Corinthians 1">I Corinthians 1
<option value="I Corinthians 2">I Corinthians 2
<option value="I Corinthians 3">I Corinthians 3
<option value="I Corinthians 4">I Corinthians 4
<option value="I Corinthians 5">I Corinthians 5
<option value="I Corinthians 6">I Corinthians 6
<option value="I Corinthians 7">I Corinthians 7
<option value="I Corinthians 8">I Corinthians 8
<option value="I Corinthians 9">I Corinthians 9
<option value="I Corinthians 10">I Corinthians 10
<option value="I Corinthians 11">I Corinthians 11
<option value="I Corinthians 12">I Corinthians 12
<option value="I Corinthians 13">I Corinthians 13
<option value="I Corinthians 14">I Corinthians 14
<option value="I Corinthians 15">I Corinthians 15
<option value="I Corinthians 16">I Corinthians 16
<option value="II Corinthians 1">II Corinthians 1
<option value="II Corinthians 2">II Corinthians 2
<option value="II Corinthians 3">II Corinthians 3
<option value="II Corinthians 4">II Corinthians 4
<option value="II Corinthians 5">II Corinthians 5
<option value="II Corinthians 6">II Corinthians 6
<option value="II Corinthians 7">II Corinthians 7
<option value="II Corinthians 8">II Corinthians 8
<option value="II Corinthians 9">II Corinthians 9
<option value="II Corinthians 10">II Corinthians 10
<option value="II Corinthians 11">II Corinthians 11
<option value="II Corinthians 12">II Corinthians 12
<option value="II Corinthians 13">II Corinthians 13
<option value="Galatians 1">Galatians 1
<option value="Galatians 2">Galatians 2
<option value="Galatians 3">Galatians 3
<option value="Galatians 4">Galatians 4
<option value="Galatians 5">Galatians 5
<option value="Galatians 6">Galatians 6
<option value="Ephesians 1">Ephesians 1
<option value="Ephesians 2">Ephesians 2
<option value="Ephesians 3">Ephesians 3
<option value="Ephesians 4">Ephesians 4
<option value="Ephesians 5">Ephesians 5
<option value="Ephesians 6">Ephesians 6
<option value="Phillipians 1">Phillipians 1
<option value="Phillipians 2">Phillipians 2
<option value="Phillipians 3">Phillipians 3
<option value="Phillipians 4">Phillipians 4
<option value="Colossians 1">Colossians 1
<option value="Colossians 2">Colossians 2
<option value="Colossians 3">Colossians 3
<option value="Colossians 4">Colossians 4
<option value="I Thessalonians 1">I Thessalonians 1
<option value="I Thessalonians 2">I Thessalonians 2
<option value="I Thessalonians 3">I Thessalonians 3
<option value="I Thessalonians 4">I Thessalonians 4
<option value="I Thessalonians 5">I Thessalonians 5
<option value="II Thessalonians 1">II Thessalonians 1
<option value="II Thessalonians 2">II Thessalonians 2
<option value="II Thessalonians 3">II Thessalonians 3
<option value="I Timothy 1">I Timothy 1
<option value="I Timothy 2">I Timothy 2
<option value="I Timothy 3">I Timothy 3
<option value="I Timothy 4">I Timothy 4
<option value="I Timothy 5">I Timothy 5
<option value="I Timothy 6">I Timothy 6
<option value="II Timothy 1">II Timothy 1
<option value="II Timothy 2">II Timothy 2
<option value="II Timothy 3">II Timothy 3
<option value="II Timothy 4">II Timothy 4
<option value="Titus 1">Titus 1
<option value="Titus 2">Titus 2
<option value="Titus 3">Titus 3
<option value="Philemon 1">Philemon 1
<option value="Hebrews 1">Hebrews 1
<option value="Hebrews 2">Hebrews 2
<option value="Hebrews 3">Hebrews 3
<option value="Hebrews 4">Hebrews 4
<option value="Hebrews 5">Hebrews 5
<option value="Hebrews 6">Hebrews 6
<option value="Hebrews 7">Hebrews 7
<option value="Hebrews 8">Hebrews 8
<option value="Hebrews 9">Hebrews 9
<option value="Hebrews 10">Hebrews 10
<option value="Hebrews 11">Hebrews 11
<option value="Hebrews 12">Hebrews 12
<option value="Hebrews 13">Hebrews 13
<option value="James 1">James 1
<option value="James 2">James 2
<option value="James 3">James 3
<option value="James 4">James 4
<option value="James 5">James 5
<option value="I Peter 1">I Peter 1
<option value="I Peter 2">I Peter 2
<option value="I Peter 3">I Peter 3
<option value="I Peter 4">I Peter 4
<option value="I Peter 5">I Peter 5
<option value="II Peter 1">II Peter 1
<option value="II Peter 2">II Peter 2
<option value="II Peter 3">II Peter 3
<option value="I John 1">I John 1
<option value="I John 2">I John 2
<option value="I John 3">I John 3
<option value="I John 4">I John 4
<option value="I John 5">I John 5
<option value="II John 1">II John 1
<option value="III John 1">III John 1
<option value="Jude 1">Jude 1
<option value="Revelation 1">Revelation 1
<option value="Revelation 2">Revelation 2
<option value="Revelation 3">Revelation 3
<option value="Revelation 4">Revelation 4
<option value="Revelation 5">Revelation 5
<option value="Revelation 6">Revelation 6
<option value="Revelation 7">Revelation 7
<option value="Revelation 8">Revelation 8
<option value="Revelation 9">Revelation 9
<option value="Revelation 10">Revelation 10
<option value="Revelation 11">Revelation 11
<option value="Revelation 12">Revelation 12
<option value="Revelation 13">Revelation 13
<option value="Revelation 14">Revelation 14
<option value="Revelation 15">Revelation 15
<option value="Revelation 16">Revelation 16
<option value="Revelation 17">Revelation 17
<option value="Revelation 18">Revelation 18
<option value="Revelation 19">Revelation 19
<option value="Revelation 20">Revelation 20
<option value="Revelation 21">Revelation 21
<option value="Revelation 22">Revelation 22
<option value="" SELECTED>Book - Chapter
</select></td></tr>
</div>
<div class="form-group">
<tr><td><input type="text" name="nrn" value="Verse" size="1" id="modlgn-username" class="inputbox" onFocus="this.value=''"></td></tr>
</div>
<tr><td><input class="btn btn-success" type="submit" value="OK" class="button"></td></tr>

<?php
$livron=trim(JRequest::getVar('livron',''));
$nrn=trim(JRequest::getInt('nrn','')); // Assim fica não setado

if(isset($livron)){
	$db = JFactory::getDBO();
	$query = "SELECT nr,versiculo FROM #__nt WHERE livro = '$livron' AND nr = ".$nrn;
	$db->setQuery( $query);
	$reg_rand = $db->loadRow();

	if($nrn && $nrn <=$reg_rand[0]){
		print "<tr><td colspan=\"3\"><div style='font-weight:bold;'><b>Book</b>: <i>".$livron.' Verso: '.$nrn.'</div><br><div class=\"login-greeting\">'.$reg_rand[1]."</i></div></td></tr>";
	}else{
		if($nrn !=$reg_rand[0] && $nrn !=0) print "<tr><td><div class=\"login-greeting\"><b>Book</b>:<i>".$livron." Verso:".$nrn."<br>Not found!</i></div></td></tr>";
	}
}
print "</table>
</div>
</form>";

