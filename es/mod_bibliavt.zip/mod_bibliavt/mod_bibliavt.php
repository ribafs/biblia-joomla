<?php 
/**
 * @ mod_bibliavt.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined('_JEXEC') or die('Restricted access'); 

$db = JFactory::getDBO();
$query = "SELECT libro,nr,versiculo FROM #__vt ORDER BY rand( )";
$db->setQuery( $query, 0, 1 );
$reg_rand = $db->loadRow();

if(isset($reg_rand[0])){
	print "<div class=\"login-greeting\"><b>Libro</b>: <i>".$reg_rand[0].', Verso: '.$reg_rand[1].'<br>'.$reg_rand[2].'</i></div>';
}
?> 
