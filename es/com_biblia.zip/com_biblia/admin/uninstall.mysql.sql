DROP TABLE #__nt;
DROP TABLE #__vt;
