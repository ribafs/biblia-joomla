DROP TABLE #__bibliavt;
