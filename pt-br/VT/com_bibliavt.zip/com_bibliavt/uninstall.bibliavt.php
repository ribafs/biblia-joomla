<?php
/**
 * @ uninstall.bibliavt.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_uninstall()
{
	?>
	<div class="header">O Versículo do dia (VT) agora foi removido do seu sistema.</div>
	<p>
	O Versículo do dia agora foi removido do seu sistema.
	</p>
	<?php
}

?>
