<?php 
/**
 * @ mod_bibliavt.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined('_JEXEC') or die('Restricted access'); 

?> 
<form method="post" action="">
<div class="form-group">
<table class="table">
<div class="form-group">
<tr><td><b>Livro</td>
<td>
<select name="livrov">
<option value="1Cr">1Crônicas
<option value="2Cr">2Crônicas
<option value="1Rs">1Reis
<option value="2Rs">2Reis
<option value="1Sm">1Samuel
<option value="2Sm">2Samuel
<option value="Ct">Cânticos
<option value="Dt">Deuteronômio
<option value="Ec">Eclesiastes
<option value="Ed">Esdras
<option value="Et">Ester
<option value="Ex">Êxodo
<option value="Ez">Ezequiel
<option value="Gn">Gênesis
<option value="Is">Isaías
<option value="Jó">Jó
<option value="Jr">Jeremias
<option value="Js">Josué
<option value="Jz">Juízes
<option value="Lm">Lamentações
<option value="Lv">Levítico
<option value="Ne">Neemias
<option value="Nm">Números
<option value="Pv">Provérbios
<option value="Rt">Rute
<option value="Sl">Salomão
<option value="<?=($_POST['livrov']=='')?'Selecione':$_POST['livrov']?>" SELECTED><?=($_POST['livrov']=='')?'Selecione':$_POST['livrov']?>
</select></td></tr>
</div>
<div class="form-group">
<tr><td><b>Cap</td><td><input type="text" name="capitulov" value="<?=($_POST['capitulov']=='')?1:$_POST['capitulov']?>" size="1"></td></tr>
</div>
<div class="form-group">
<tr><td><b>Vers</td><td><input type="text" name="versiculov" value="<?=($_POST['versiculov']=='')?1:$_POST['versiculov']?>" size="1"></td></tr>
</div>
<tr><td></td><td><input class="btn btn-success" type="submit" value="OK"></td></tr>

<?php
$livrov=JRequest::getVar('livrov','');
if(isset($livrov)){
$capitulov=JRequest::getVar('capitulov',1);
$versiculov=JRequest::getVar('versiculov',1);

	$db = JFactory::getDBO();
	$query = "SELECT palavra FROM #__bibliavt WHERE livro = '$livrov' AND capitulo = $capitulov AND versiculo = $versiculov ORDER BY rand( )";
	$db->setQuery( $query, 0, 1 );
	//$reg_rand = $db->loadObjectList();
	$reg_rand = $db->loadRow();

	print "<tr><td colspan=\"3\">".$reg_rand[0]."</td></tr></table>
</form>";
	
	// Fonte da Bíblia : Almeida Corrigida Fiel
	// http://br.groups.yahoo.com/group/bibliaonlinephp/files/
}
?>

