<?php 
/**
 * @ mod_buscant.php
 * @ author-name Ribamar FS
 * @ copyright	Copyright (C) 2012 Ribamar FS.
 * @ license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined('_JEXEC') or die('Restricted access'); 
?> 

<form method="post" action="">
<div class="form-group">
<table class="table table-sm">
<div class="form-group">
<tr><td><b>Livro</td>
<td>
<select name="livro" class="form-control">
<option value="1Co">1Coríntios
<option value="2Co">2Coríntios
<option value="1Jo">1João
<option value="2Jo">2João
<option value="3Jo">3João
<option value="1Pe">1Pedro
<option value="2Pe">2Pedro
<option value="1Tm">1Timóteo
<option value="2Tm">2Timóteo
<option value="1Ts">1Tessalonicenses
<option value="2Ts">2Tessalonicenses
<option value="Ap">Apocalipse
<option value="At">Atos
<option value="Cl">Colossenses
<option value="Ef">Efésios
<option value="Fm">Filemom
<option value="Fp">Filipenses
<option value="Gl">Gálatas
<option value="Hb">Hebreus
<option value="Jd">Judas
<option value="Jo">João
<option value="Lc">Lucas
<option value="Mt">Marcos
<option value="Rm">Romanos
<option value="Tg">Tiago
<option value="<?=(JRequest::getVar('livro','')=='')?'Selecione':JRequest::getVar('livro','')?>" SELECTED><?=(JRequest::getVar('livro','')=='')?'Selecione':JRequest::getVar('livro','');?>
</select></td></tr>
</div>
<div class="form-group">
<tr><td><b>Cap</td><td><input type="text" name="capitulo" class="form-control" value="<?=(JRequest::getVar('capitulo',1)=='')?1:JRequest::getVar('capitulo',1);?>" size="1"></td></tr>
</div>
<div class="form-group">
<tr><td><b>Vers</td><td><input type="text" class="form-control" name="versiculo" value="<?=(JRequest::getVar('versiculo',1)=='')?1:JRequest::getVar('versiculo',1);?>" size="1"></td></tr>
</div>
<tr><td></td><td><input class="btn btn-success" type="submit" value="Ok"></td></tr>

<?php

$livro=JRequest::getVar('livro','');
if(isset($livro)){
$capitulo=JRequest::getVar('capitulo',1);
$versiculo=JRequest::getVar('versiculo',1);

	$db = JFactory::getDBO();
	$query = "SELECT palavra FROM #__bibliant WHERE livro = '$livro' AND capitulo = $capitulo AND versiculo = $versiculo ORDER BY rand( )";
	$db->setQuery( $query, 0, 1 );
	//$reg_rand = $db->loadObjectList();
	$reg_rand = $db->loadRow();

	if(isset($reg_rand[0])){
	print "<tr><td colspan=\"3\">".$reg_rand[0]."</td></tr>
</form>";
	}
	// Fonte da Bíblia :
	// http://br.groups.yahoo.com/group/bibliaonlinephp/files/
}
?>
<tr><td>
<a href="https://github.com/ribafs/biblia-joomla" title="Download do pacote da Bíblia em 3 idiomas" target="_blank" style="font-size:12px"><i>Download</i></a>
</td></tr>
</table>
