The Bible - Old and New Testaments

One component and four modules (2 for NT and 2 for AT), to find and display a random verse each time you visit the site.

Component is mandatory. The modules depend on the components, where they receive information (database).

Two modules that display a random verse each visit / update the site, one for NT and one for the AT.

The Bible in English is a version "Holy Bible King James Version Cambridge Edition"
The King James Version is in the public domain, this version "Cambridge Edition" is protected by http://www.bibleprotector.com/.

Published by Cambridge University Press and Collins Publishers around 1900, is the product of a cleaning and inspection since 1611 when King James the first versions were published. 
The electronic edition was held in Australia.

Sob a licença - GPL2.


Ribamar FS - http://ribafs.org
